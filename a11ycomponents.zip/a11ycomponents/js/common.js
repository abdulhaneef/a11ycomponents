//copy code

function copyToClipboard(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
  
 //alerts
 $(document).ready(function(){

 //flyout related code
	$('#openNav').on('keydown',function(e){
	var $this=$(this);
	if(e.keyCode==13){
		setTimeout(function(){
			console.log($('#mySidenav #closeNav').length);		
			$this.addClass('active-flyout');
			$('#mySidenav #closeNav').focus();					 
		},1)

		}
	})
	
	
	$('#mySidenav ul li:last').on('keydown',function(e){
	if(e.keyCode==9){
	if(!e.shiftKey){
	setTimeout(function(){
	$('#mySidenav #closeNav').focus();
	},1)
	
	}
	}
	})
	
	$('#mySidenav #closeNav').on('keydown',function(e){
	if(e.keyCode==9){
	if(e.shiftKey){
	setTimeout(function(){$('#mySidenav ul li:last a').focus();},1)
	
	}
	}
	})
//flyout related code

							
 $('.button').click(function(){
            if ($('.form-group input#Form_Newpassword').val() == ""){
                alert('enter New Password');
				$(".form-group input#Form_Newpassword").focus();
            }else if($('.form-group input#Form_Confirmpassword').val() == ""){
			alert('enter Confirm Password');
				$(".form-group input#Form_Confirmpassword").focus();
			}else {
			reset();
			}
        });
		function reset(){
		var newPassword= $('.form-group input#Form_Newpassword').val(); 
var confirmPassword= $('.form-group input#Form_Confirmpassword').val(); 
		if(newPassword != confirmPassword){
		alert("passwords are not matching");
		$(".form-group input#Form_Confirmpassword").focus();
		}
		else {
		alert("password reset successfully");
		}
		
		}
	$('.render-alerts-code').text($("#alertsExample").html()); 
 });
  
$(document).ready(function(){
    $("#togglecontrast").click(function(){
        $("body").toggleClass("highmode");
    });	
});
  

  
  $(document).ready(function() {
      $(".wm").click(function() {
          $('body').removeClass("highmode normalmode").addClass("whitemode");
      });
      $(".bm").click(function() {
          $('body').removeClass("whitemode normalmode").addClass("highmode");
      });
      $(".nm").click(function() {
          $('body').removeClass("whitemode highmode").addClass("normalmode");
      });
  });

  function myFunction() {
      var x = $(".red").attr("aria-pressed");
      if (x == "false") {
          x = "true"
      } else {
          x = "false"
      }
      $(".red").attr("aria-pressed", x);
      $(".red").innerHTML = "aria-pressed =" + x;
  }


  function accordiontoggle() {
      var x = $(".acctoggle").attr("aria-expanded");
      if (x == "false") {
          x = "true"
      } else {
          x = "false"
      }
      $(".acctoggle").attr("aria-expanded", x);
      $(".acctoggle").innerHTML = "aria-expanded =" + x;
  }

  $(document).ready(function() {
							 $(".dropdown-trigger").dropdown();
  $('.modal').modal();
      $('.collapsible').collapsible();
	  $('.render-accordion-code').text($("#accordsExample").html());	
  	 $('.render-alerts-code').text($("#alertsExample").html()); 
	 $('.render-flyouts-code').text($("#flyoutsExample").html());
	 $('.render-table-code').text($("#tableExample").html()); 
$('.render-form-code').text($("#formExample").html());
$('.render-tab-code').text($("#tabExample").html());
 $('.render-menu-code').text($("#menuExample").html());
  $('.render-modal-code').text($("#modalExample").html());
    $('.render-ariaErrorMsg-code').text($("#ariaErrmsgExample").html());
$('.render-accordion-code').text($("#accordsExample").html());

  });
$(document).ready(function(){
    $("#openNav").click(function(){
        $("#mySidenav").toggle();
    });
	$("#closeNav").click(function(){
        $("#mySidenav").toggle();
    });
	$('#mySidenav #closeNav').click(function(e){
		$('.active-flyout').focus().removeClass('active-flyout');		
	})
	
});
  
  $(document).keydown(function(e){
	if($('#mySidenav').css('display')=="block")
	if(e.keyCode==27){
		$("#mySidenav").toggle();
		$('.active-flyout').focus().removeClass('active-flyout');	
	}
  })
//code render

$(document).ready(function() {
	$('#date1').datepicker({
	});
});
	
	//Search Container
	
$(document).ready(function() {	
	
$('#searchList li').each(function(){
$(this).attr('data-search', $(this).text().toLowerCase());
});

$('#searchContainer').on('keyup', function(){

var searchWord = $(this).val().toLowerCase();

    $('#searchList li').each(function(){

        if ($(this).filter('[data-search *= ' + searchWord + ']').length > 0 || searchWord.length < 1) {
            $(this).show();
        } else {
            $(this).hide();
        }

    });

});
 $("button[data-mode]").click(function() {
    $("head link#mode").attr("href", $(this).data("mode"));
});
	});
	
	
//forms

$(document).ready(function(){
$("#fname-error").addClass("hidden");
$("#lname-error").addClass("hidden");
$("#email-error").addClass("hidden");
$("#pswd-error").addClass("hidden");
$("#signForm").on("submit",function(ev){
ev.preventDefault();
var First_Name = $("#fname").val();
var Last_Name = $("#lname").val();
var Email_Address = $("#email").val();
var Password = $("#pswd").val();
if(First_Name.length < 1){
$("#fname-error").removeClass("hidden").addClass("showFormMessage");
}else{
$("#fname-error").addClass("hidden").removeClass("showFormMessage");
}
if(Last_Name.length < 1){
$("#lname-error").removeClass("hidden").addClass("showFormMessage");
}else{
$("#lname-error").addClass("hidden").removeClass("showFormMessage");
}
if (Email_Address.length < 1) {
      $("#email-error").addClass("showFormMessage").removeClass("hidden");
	   var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var validEmail = regEx.test(email);
	  $('#email').html('<span class="error" role="alert">Please Enter valid email address</span>');
    } 
     else{
		   $("#email-error").addClass("hidden").removeClass("showFormMessage");
	  }
	if(Password.length < 8){
	$("#pswd-error").addClass("showFormMessage").removeClass("hidden");
	$("#pswd").focus();
	}else{
	$("#pswd-error").addClass("hidden").removeClass("showFormMessage");
	}
	$('#signForm input').each(function(){if($(this).val()==""){
$(this).focus();
return false;
}
});
	

});

<!--error msg-->
$("#fNameErrorMsg").addClass("hidden");
$("#lNameErrorMsg").addClass("hidden");
$("#registerErrorMsg").on("click", function(evnt){
	evnt.preventDefault();
var invalidFName = $("#fName").val();
var invalidLName = $("#lName").val();
if(invalidFName.length < 1){
$("#fNameErrorMsg").removeClass("hidden").addClass("showErrorMessage");
$("#fName").attr("aria-invalid","true");
//$("#fNameErrorMsg").attr("aria-live","assertive");
}else{
$("#fNameErrorMsg").addClass("hidden").removeClass("showErrorMessage");
$("#fName").attr("aria-invalid","false");
//$("#fNameErrorMsg").attr("aria-live","off");
}
if(invalidLName.length < 1){
$("#lNameErrorMsg").removeClass("hidden").addClass("showErrorMessage");
$("#lName").attr("aria-invalid","true");
//$("#lNameErrorMsg").attr("aria-live","assertive");
}else{
$("#lNameErrorMsg").addClass("hidden").removeClass("showErrorMessage");
$("#lName").attr("aria-invalid","false");
//$("#lNameErrorMsg").attr("aria-live","off");
}
$('#registerForm input').each(function(){if($(this).val()==""){
$(this).focus();
return false;
}
});
});
});



