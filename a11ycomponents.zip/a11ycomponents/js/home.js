
//function openNav() {
//    document.getElementById("mySidenav").style.width = "250px";
//    document.getElementById("navbtn").style.marginRight = "250px";
//}
//
//function closeNav() {
//    document.getElementById("mySidenav").style.width = "0";
//    document.getElementById("navbtn").style.marginRight= "0";
//}


$(document).ready(function(){            
    $("#wm").click(function(){
      $('body').removeClass("highmode normalmode").addClass("whitemode");
    });
    $("#hm").click(function(){
      $('body').removeClass("whitemode normalmode").addClass("highmode");
    });
    $("#nm").click(function(){
      $('body').removeClass("whitemode highmode").addClass("normalmode");
    });
  });



$(document).ready(function(){
    $("#openNav").click(function(){
        $("#mySidenav").toggle();
    });
	$("#closeNav").click(function(){
        $("#mySidenav").toggle();
    });
});


$(document).ready(function(){
	//scroll
	$("#searchList li a").click(function(){
var $id=$(this).attr('href');
$('html, body').animate({
        scrollTop: $("#Example "+$id+" div").offset().top
    }, 500);
});
 $(window).scroll(function(e) {
 e.preventDefault();
    var scrollLocation = $(window).scrollTop();
    
    $("#searchList li a").each(function(e) {
      var $id1=$(this).attr('href');
      var sectionDistance = $("#Example "+$id1+" div").offset().top;
      
      if ( scrollLocation >= sectionDistance) {
         $(this).parent().addClass("activeComponent");
        $(this).parent().siblings().removeClass("activeComponent");
		}
      });
    });
    
//Search Container
$('#searchList li').each(function(){
$(this).attr('data-search', $(this).text().toLowerCase());
});

$('#searchContainer').on('keyup', function(){

var searchWord = $(this).val().toLowerCase();

    $('#searchList li').each(function(){

        if ($(this).filter('[data-search *= ' + searchWord + ']').length > 0 || searchWord.length < 1) {
            $(this).show();
        } else {
            $(this).hide();
        }

    });

});
 $("button[data-mode]").click(function() {
    $("head link#mode").attr("href", $(this).data("mode"));
});

//accordion
var accordionButtons = $('.accordion-controls li .accordion-header');

function stateChangeAccordion() {
  $('.accordion-controls li .accordion-header').on('click', function(e) {
    $control = $(this);

    accordionContent = $control.attr('aria-controls');
    collapsedAccordion($control[0]);

    isAriaExp = $control.attr('aria-expanded');
    newAriaExp = (isAriaExp == "false") ? "true" : "false";
    $control.attr('aria-expanded', newAriaExp);

    isAriaHid = $('#' + accordionContent).attr('aria-hidden');
    if (isAriaHid == "true") {
      $('#' + accordionContent).attr('aria-hidden', "false");
      $('#' + accordionContent).css('display', 'block');
    } else {
      $('#' + accordionContent).attr('aria-hidden', "true");
      $('#' + accordionContent).css('display', 'none');
    }
  });
};

function collapsedAccordion(e) {
  for (var i=0; i<accordionButtons.length; i++) {
    if (accordionButtons[i] != e) {
      if (($(accordionButtons[i]).attr('aria-expanded')) == 'true') {
        $(accordionButtons[i]).attr('aria-expanded', 'false');
        content = $(accordionButtons[i]).attr('aria-controls');
        $('#' + content).attr('aria-hidden', 'true');
        $('#' + content).css('display', 'none');
      }
    }
  }
};
stateChangeAccordion();
$('.render-accordion-code').text($("#accordsExample").html());
	
//alerts
 $('.button').click(function(){
            if ($('.form-group input#Form_Newpassword').val() == ""){
                alert('enter New Password');
				$(".form-group input#Form_Newpassword").focus();
            }else if($('.form-group input#Form_Confirmpassword').val() == ""){
			alert('enter Confirm Password');
				$(".form-group input#Form_Confirmpassword").focus();
			}else {
			reset();
			}
        });
		function reset(){
		var newPassword= $('.form-group input#Form_Newpassword').val(); 
var confirmPassword= $('.form-group input#Form_Confirmpassword').val(); 
		if(newPassword != confirmPassword){
		alert("passwords are not matching");
		$(".form-group input#Form_Confirmpassword").focus();
		}
		else {
		alert("password reset successfully");
		}
		
		}
	$('.render-alerts-code').text($("#alertsExample").html()); 

//flyouts
//	var panel = $('#mySidenav');
// var close = $('#closeNav');
// var flyoutButton =  $("#openNav");
// panel.removeClass('visible').animate({'margin-left':'-999px'}).css("display","none");
// $('#closeNav').on("click", function(){
//
//	
//panel.removeClass('visible').animate({'margin-left':'-999px'}).css("display","none");
//	flyoutButton.focus().attr("aria-expanded","false");
//
// });
 $("#buttonClick").on("click",function(e){
e.preventDefault();
	if (panel.hasClass("visible")) {
			$(this).attr("aria-expanded","false");
			panel.removeClass('visible').animate({'margin-left':'-999px'}).css("display","none");
		} else {
			$(this).attr("aria-expanded","true");
			panel.addClass('visible').animate({'margin-left':'0px'}).css("display","block");
			close.focus();
		}		
return false;
 });
 
var $firstEle2 = document.querySelector(".sidenav .dummy-link-first");
        if ($firstEle2) {
            $firstEle2.addEventListener("focus", stableFocusable);
        }        
        var $lastEle2 = document.querySelector(".sidenav .dummy-link-last");
        if ($lastEle2) {
            $lastEle2.addEventListener("focus", stableFocusableFlyout);
        }       
        function stableFocusableFlyout() {
           
                var $popUpCloseFlyout = document.querySelector("#closeNav");
                $popUpCloseFlyout.focus();
            
        }

$('.render-flyouts-code').text($("#flyoutsExample").html());
	
//forms
$("#fname-error").addClass("hidden");
$("#lname-error").addClass("hidden");
$("#email-error").addClass("hidden");
$("#pswd-error").addClass("hidden");
$("#signForm").on("submit",function(ev){
ev.preventDefault();
var First_Name = $("#fname").val();
var Last_Name = $("#lname").val();
var Email_Address = $("#email").val();
var Password = $("#pswd").val();
if(First_Name.length < 1){
$("#fname-error").removeClass("hidden").addClass("showFormMessage");
}else{
$("#fname-error").addClass("hidden").removeClass("showFormMessage");
}
if(Last_Name.length < 1){
$("#lname-error").removeClass("hidden").addClass("showFormMessage");
}else{
$("#lname-error").addClass("hidden").removeClass("showFormMessage");
}
if (Email_Address.length < 1) {
      $("#email-error").addClass("showFormMessage").removeClass("hidden");
	   var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var validEmail = regEx.test(email);
	  $('#email').html('<span class="error" role="alert">Please Enter a email address</span>');
    } 
     else{
		   $("#email-error").addClass("hidden").removeClass("showFormMessage");
	  }
	if(Password.length < 8){
	$("#pswd-error").addClass("showFormMessage").removeClass("hidden");
	$("#pswd").focus();
	}else{
	$("#pswd-error").addClass("hidden").removeClass("showFormMessage");
	}
	$('#signForm input').each(function(){if($(this).val()==""){
$(this).focus();
return false;
}
});
	
	
});
	$('.render-form-code').text($("#formExample").html());
	
//table
$('.render-table-code').text($("#tableExample").html()); 

//tooltip
$("#uname_tooltip").addClass("hidden_tooltip");
$("#pswd_tooltip").addClass("hidden_tooltip");
$("input#uname").mouseover(function(){
$("#uname_tooltip").removeClass("hidden_tooltip").addClass("show_tooltip ");
});
$("input#psd").mouseover(function(){
$("#pswd_tooltip").removeClass("hidden_tooltip").addClass("show_tooltip ");
});
$("input#uname").mouseleave(function(){
$("#uname_tooltip").removeClass("show_tooltip ").addClass("hidden_tooltip");
});
$("input#psd").mouseleave(function(){
$("#pswd_tooltip").removeClass("show_tooltip ").addClass("hidden_tooltip");
});
$("input#uname").focus(function(){
$("#uname_tooltip").removeClass("hidden_tooltip").addClass("show_tooltip ");
});
$("input#psd").focus(function(){
$("#pswd_tooltip").removeClass("hidden_tooltip").addClass("show_tooltip ");
});
$("input#uname").blur(function(){
$("#uname_tooltip").removeClass("show_tooltip ").addClass("hidden_tooltip");
});
$("input#psd").blur(function(){
$("#pswd_tooltip").removeClass("show_tooltip ").addClass("hidden_tooltip");
});
$("#submitTooltip").click(function(){
if($("input#uname").val()==""){
$("#uname_tooltip").removeClass("hidden_tooltip").addClass("show_tooltip ");
$("input#uname").focus();
} else if($("input#psd").val()==""){
$("#pswd_tooltip").removeClass("hidden_tooltip").addClass("show_tooltip ");
$("input#psd").focus();
}else{
alert("Login successful");
}

});
	$('.render-tooltip-code').text($("#tooltipExample").html());

//tab
$("li[role='tab']").click(function(){  
	$("li[role='tab']").attr("aria-selected","false");  
 	$(this).attr("aria-selected","true");  
	var tabpanid= $(this).attr("aria-controls"); 
   var tabpan = $("#"+tabpanid);  
	$("div[role='tabpanel']").attr("aria-hidden","true"); 
	tabpan.attr("aria-hidden","false");  
 });
 $("li[role='tab']").keydown(function(ev) {
if (ev.which ==13) {
$(this).click()
}
});
$("li[role='tab']").keydown(function(ev) {
if ((ev.which ==39)||(ev.which ==37)) {
 var selected= $(this).attr("aria-selected");
 if (selected =="true"){
   $("li[aria-selected='false']").attr("aria-selected","true").focus() ;
   $(this).attr("aria-selected","false");
   var tabpanid= $("li[aria-selected='true']").attr("aria-controls");
   var tabpan = $("#"+tabpanid);
   $("div[role='tabpanel']").attr("aria-hidden","true");
   tabpan.attr("aria-hidden","false");
   }
}
});
$('.render-tab-code').text($("#tabExample").html());

//menubar
$(".navbar-nav li").on("click",function(){
 $(".navbar-nav .sub-menu").css("display","none");
 $(this).find("ul:first").css({visibility:"visible",display:"block"});
 $(this).attr("aria-expanded","true");
 $(this).siblings().attr("aria-expanded","false");
})
$(document).click(function(e) {
    var container = $(".navbar-nav li");    
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
        $(".navbar-nav .sub-menu").css("display","none");
  $(".sub-menu").attr("aria-expanded","false");
    }
});

$(".navbar-nav li").on("keydown",function(e){
if(e.keyCode==13){
$(this).find("ul:first").css({visibility:"visible",display:"block"});
$(this).attr("aria-expanded","true");
}
});

$(".navbar-nav .sub-menu li:last-child").keydown(function(e){
if(e.keyCode==9)
{
if(!e.shiftKey){
$(this).closest(".sub-menu").css("display","none");
$(".sub-menu").closest('li').attr("aria-expanded","false");
}
}
});

$(".navbar-nav > li").keydown(function(e){
 var container=$(".navbar-nav .sub-menu li");
if(e.keyCode==9)
{
if(e.shiftKey){ 
if (!container.is(e.target) && container.has(e.target).length === 0) 
{
$(".navbar-nav .sub-menu").css("display","none");
$(".sub-menu").closest('li').attr("aria-expanded","false");
}
}
}
});

//$(".navbar-nav > li").keydown(function(e){
 $(".sub-menu li:first-child li").keydown(function(e){
if(e.keyCode==9)
{
if(e.shiftKey){
$(this).closest("li").find(".sub-menu").css("display","none");
$(".sub-menu").closest('li').attr("aria-expanded","false");
}
}
});

 $('.render-menu-code').text($("#menuExample").html());
 
 //modal
var modal = document.getElementById('myModal');
var cancelModal = document.getElementById("cancel");
var span = document.getElementById("closebtnpopup");
$("#myBtn").on("click",function(){
	$("#myModal").css("display","block");
	$("#closebtnpopup").focus();
	
});
$("#closebtnpopup").on("click",function(){
	$("#myModal").css("display","none");
	$("#myBtn").focus();
	
});
$("#cancel").on("click",function(){
	$("#myModal").css("display","none");
	$("#myBtn").focus();
	
});

window.onclick = function closeFunction(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
document.addEventListener('DOMContentLoaded', function () {


  document.addEventListener('keydown',EscapeTrigger);
  function EscapeTrigger(e){
  if(e.keyCode==27 || e.keyCode===13){
   var modal = document.getElementById('myModal');
   modal.style.display = "none";
  }
  } 


  });
   
  $(".modal-content .dummy-link-first").on("focus", setFocusLast);
                $(".modal-content .dummy-link-last").on("focus", stableFocusable);     
        
               function setFocusLast(){
			    var $popUpClose = document.getElementById("cancel");
                //$popUpClose.focus();
			   }
        function stableFocusable() {
                var $popUpClose = document.getElementById("closebtnpopup");
                $popUpClose.focus();
        }
		
  $('.render-modal-code').text($("#modalExample").html());
  
  
  
  //Error Message
$("#fNameErrorMsg").addClass("hidden");
$("#lNameErrorMsg").addClass("hidden");
$("#registerErrorMsg").on("click", function(evnt){
	evnt.preventDefault();
var invalidFName = $("#fName").val();
var invalidLName = $("#lName").val();
if(invalidFName.length < 1){
$("#fNameErrorMsg").removeClass("hidden").addClass("showErrorMessage");
$("#fName").attr("aria-invalid","true");
//$("#fNameErrorMsg").attr("aria-live","assertive");
}else{
$("#fNameErrorMsg").addClass("hidden").removeClass("showErrorMessage");
$("#fName").attr("aria-invalid","false");
//$("#fNameErrorMsg").attr("aria-live","off");
}
if(invalidLName.length < 1){
$("#lNameErrorMsg").removeClass("hidden").addClass("showErrorMessage");
$("#lName").attr("aria-invalid","true");
//$("#lNameErrorMsg").attr("aria-live","assertive");
}else{
$("#lNameErrorMsg").addClass("hidden").removeClass("showErrorMessage");
$("#lName").attr("aria-invalid","false");
//$("#lNameErrorMsg").attr("aria-live","off");
}
$('#registerForm input').each(function(){if($(this).val()==""){
$(this).focus();
return false;
}
});
});

  $('.render-ariaErrorMsg-code').text($("#ariaErrmsgExample").html());
  
  
  
  
 $(document).on('keydown',function(e){
	  $('.navbar-nav a').click(function(e){
	  e.preventDefault();
	  });
	    if(e.keyCode===27){
			$("#buttonClick").focus().attr("aria-expanded","false");
	   panel.removeClass('visible').animate({'margin-left':'-999px'}).css("display","none");
	  
	  }
	  });
});






function html2text(html) {
    var tag = document.createElement('.custom-body textarea');
    tag.innerHTML = html;
    
    return tag.innerText;
}


